const body = document.body,
  themeSwitch = document.querySelector("#theme-switch");
themeSwitch.addEventListener("click", () => {
  body.classList.toggle("light");
});

const menus = document.querySelector("#menus"),
hamburger = document.querySelector("#hamburger");

hamburger &&
hamburger.addEventListener("click", () => {
  hamburger.classList.toggle("close");
  menus.classList.toggle("mobile");
});